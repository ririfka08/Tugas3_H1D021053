import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MenuMakananScreen extends StatelessWidget {
  void _logout(BuildContext context) async {
    // Hapus data login dari shared preferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('loggedIn');

    // Navigasi ke halaman login setelah logout
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu Makanan'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            ListTile(
              title: Text('Makanan'),
              onTap: () {
                Navigator.pop(context); // Tutup drawer
              },
            ),
            ListTile(
              title: Text('Pemesanan'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/order');
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Daftar Makanan Enak',
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            Text('1. Nasi Goreng'),
            Text('2. Mie Goreng'),
            Text('3. Sushi'),
            Text('4. Pizza'),
            Text('5. Hamburger'),
          ],
        ),
      ),
    );
  }
}
