import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PemesananScreen extends StatefulWidget {
  @override
  _PemesananScreenState createState() => _PemesananScreenState();
}

class _PemesananScreenState extends State<PemesananScreen> {
  List<String> daftarPesanan = [];

  @override
  void initState() {
    super.initState();
    _loadPesanan();
  }

  void _loadPesanan() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? pesanan = prefs.getStringList('pesanan');

    if (pesanan != null) {
      setState(() {
        daftarPesanan = pesanan;
      });
    }
  }

  void _savePesanan() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('pesanan', daftarPesanan);
  }

  void _addPesanan(String menu) {
    setState(() {
      daftarPesanan.add(menu);
      _savePesanan();
    });
  }

  void _removePesanan(String menu) {
    setState(() {
      daftarPesanan.remove(menu);
      _savePesanan();
    });
  }

  void _clearPesanan() {
    setState(() {
      daftarPesanan.clear();
      _savePesanan();
    });
  }

  void _logout(BuildContext context) async {
    // Hapus data login dari shared preferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('loggedIn');

    // Navigasi ke halaman login setelah logout
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pemesanan'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            ListTile(
              title: Text('Makanan'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/food');
              },
            ),
            ListTile(
              title: Text('Pemesanan'),
              onTap: () {
                Navigator.pop(context); // Tutup drawer
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Daftar Pemesanan',
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            if (daftarPesanan.isEmpty)
              Text('Tidak ada pesanan.'),
            for (var pesanan in daftarPesanan)
              ListTile(
                title: Text(pesanan),
                trailing: IconButton(
                  icon: Icon(Icons.remove_circle),
                  onPressed: () => _removePesanan(pesanan),
                ),
              ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _clearPesanan,
              child: Text('Bersihkan Pemesanan'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Tampilkan dialog untuk memilih makanan
          showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text('Pilih Makanan'),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    ListTile(
                      title: Text('Nasi Goreng'),
                      onTap: () {
                        _addPesanan('Nasi Goreng');
                        Navigator.of(context).pop();
                      },
                    ),
                    ListTile(
                      title: Text('Mie Goreng'),
                      onTap: () {
                        _addPesanan('Mie Goreng');
                        Navigator.of(context).pop();
                      },
                    ),
                    // Tambahkan opsi makanan lainnya di sini
                  ],
                ),
              );
            },
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
