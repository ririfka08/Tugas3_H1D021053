import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SideMenu extends StatelessWidget {
  final bool isLoggedIn;

  SideMenu({required this.isLoggedIn});

  void _logout(BuildContext context) async {
    // Hapus data login dari shared preferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('loggedIn');

    // Navigasi ke halaman login setelah logout
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          ListTile(
            title: Text('Makanan'),
            onTap: () {
              Navigator.pushReplacementNamed(context, '/food');
            },
          ),
          if (isLoggedIn)
            ListTile(
              title: Text('Pemesanan'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/order');
              },
            ),
          if (isLoggedIn)
            ListTile(
              title: Text('Logout'),
              onTap: () => _logout(context),
            ),
        ],
      ),
    );
  }
}
